import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="ZY_Frame", # Replace with your own username
    version="0.0.1",
    author="Zhang Ying",
    author_email="alexandrea@126.com",
    description="A mini nueral network framework",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/weownthenight/mini_nueral_network_framework",
    project_urls={
        "Bug Tracker": "https://github.com/weownthenight/mini_nueral_network_framework",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
)